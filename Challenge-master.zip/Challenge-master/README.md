# Challenge

In this task you must research on how to import an external file to your HTML file, in this case it is your css styling.
You must clone or download this task and when finished upload it to your github using git bash.
